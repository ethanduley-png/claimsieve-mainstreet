import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from founder_os.core import Approval, GitHubIssueAdapter, PermitAuthority, Policy, Proposal

now = 1_000
clock = lambda: now
policy = Policy("founder-os.v1", frozenset({"ethanduley-png/claimsieve-mainstreet"}))
authority = PermitAuthority(policy, b"demo-only-secret", clock)
proposal = Proposal("demo-1", "mainstreet", "github.issue.create", "ethanduley-png/claimsieve-mainstreet", "Founder OS demo", "A governed issue proposal.", ("work-order:v0.1",), "founder-os.v1", 990)
approval = Approval(proposal.proposal_id, proposal.payload_hash, "ethan", 999)
permit = authority.issue(proposal, approval)
adapter = GitHubIssueAdapter(authority, lambda p: {"status": "confirmed", "simulated": True, "issue_number": 42})
print(adapter.execute(proposal, permit))
