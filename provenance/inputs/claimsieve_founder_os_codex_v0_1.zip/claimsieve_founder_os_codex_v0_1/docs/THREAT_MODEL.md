# Threat Model

## Protected assets

- founder authority;
- repository selection;
- exact issue content;
- policy version;
- approval freshness;
- permit uniqueness;
- truthful outcome state;
- audit history.

## Threat actors

- compromised or hallucinating model;
- malicious prompt/content;
- buggy Main Street code;
- compromised adapter;
- insider with partial access;
- replaying client;
- stale worker;
- database modifier.

## Principal threats and controls

| Threat | Required control |
|---|---|
| Repository substitution | repository included in canonical payload hash and permit |
| Body mutation | exact canonical payload hash checked at execution |
| Approval reuse | approval binds proposal and hash; permit single-use |
| Stale approval | injected clock and expiry check |
| Policy drift | policy version bound into decision and permit |
| Direct adapter call | adapter requires verified permit object |
| Forged success | provider response classified as evidence; observation required for confirmation |
| Ledger editing | hash-chain reference implementation; production needs stronger storage and key controls |
| Model self-authorization | proposal runtime has no permit authority |

## Residual risks

- local JSONL can be deleted or rolled back by a privileged host administrator;
- HMAC/reference signatures are not production key management;
- external provider atomicity is impossible across a normal API boundary;
- a compromised observer can provide false confirmation;
- complete mediation depends on deployment and credential isolation;
- this package does not solve distributed split-brain.
