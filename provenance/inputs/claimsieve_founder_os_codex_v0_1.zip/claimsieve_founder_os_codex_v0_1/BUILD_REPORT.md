# Build Report

## Package

ClaimSieve + Main Street Founder OS Codex Package v0.1

## Environment

- Python reference implementation
- Standard library only
- Network disabled
- Deterministic injected clock

## Commands

```bash
python -m unittest discover -s tests -v
python examples/demo.py
```

## Test result

```text
test_ambiguous_provider_response_is_unknown (test_founder_os.FounderOSTests.test_ambiguous_provider_response_is_unknown) ... ok
test_body_mutation_after_approval_blocked (test_founder_os.FounderOSTests.test_body_mutation_after_approval_blocked) ... ok
test_direct_execution_without_permit_blocked (test_founder_os.FounderOSTests.test_direct_execution_without_permit_blocked) ... ok
test_expired_permit_blocked (test_founder_os.FounderOSTests.test_expired_permit_blocked) ... ok
test_missing_evidence_blocked (test_founder_os.FounderOSTests.test_missing_evidence_blocked) ... ok
test_policy_drift_blocked (test_founder_os.FounderOSTests.test_policy_drift_blocked) ... ok
test_replay_blocked (test_founder_os.FounderOSTests.test_replay_blocked) ... ok
test_repository_substitution_after_approval_blocked (test_founder_os.FounderOSTests.test_repository_substitution_after_approval_blocked) ... ok
test_valid_attempt (test_founder_os.FounderOSTests.test_valid_attempt) ... ok

----------------------------------------------------------------------
Ran 9 tests in 0.001s

OK
```

## Demonstration result

```text
{'proposal_id': 'demo-1', 'permit_id': 'f9269dce9c30e211796d36c9c15c691ffb24c2d52939e2f8d884c4d34e192c10', 'attempted': True, 'provider_evidence': {'status': 'confirmed', 'simulated': True, 'issue_number': 42}, 'outcome': 'confirmed', 'independently_verified': False}
```

## Verified by these tests

The test suite discriminates repository and payload substitution, missing evidence, replay, expiry, direct adapter invocation, policy drift, and ambiguous provider outcomes.

## Not established

No live GitHub call was made. The package does not establish production key security, complete mediation in deployment, independent provider observation, distributed consistency, or Rocq/runtime correspondence.
