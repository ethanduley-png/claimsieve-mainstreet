# Claims and Status Matrix — v0.33.0

| Claim | Status | Evidence | Boundary |
|---|---|---|---|
| v0.32 allowed a false signed executor rejection to become confirmed failure | Implemented and executed trace | `evidence/V032_INVARIANT_VIOLATION_TRACE.json` | Preserved v0.32 path |
| v0.33 keeps the same trace unknown | Implemented and executed | `evidence/V033_PATCHED_TRACE.json` | Python reference |
| Executor receipt is outside observer terminal trust path | Implemented and executed | Python tests, source gate, durable red team | Python reference |
| Contradictory provider evidence remains unknown | Implemented and executed | outcome vectors and durable tests | Python reference |
| Exact same-dispatch replay is narrowly guarded | Implemented and executed | provider contract gate | Offline model |
| Stripe contract clauses are mapped to scenarios | Implemented and executed | research snapshot and report | Published contract, no live API |
| MainStreet proposal bridge remains side-effect free | Implemented and executed | Node tests and source gate | Included JavaScript boundary |
| Rust executor no longer owns observer signing key | Implemented but not executed | Rust source and structural source gate | No native compilation |
| Rust matches observer receipt v2 | False / known divergence | semantic divergence report | Rust emits v1 shape |
| Rocq models independent provider outcome | Formally modeled | `rocq/DurableState.v` | Not compiler accepted here |
| Rocq theorems are formally proved | Blocked by environment | native report | No compiler output |
| Rust compiles and tests pass | Blocked by environment | native report | No cargo/rustc |
| Live Stripe unknown-outcome behavior is validated | Designed but not implemented | roadmap | No credentials or live request |
| Observer is independent by host and administrator | Designed but not implemented | architecture and limitations | Same development host |
| State is linearizable across multiple machines | Designed but not implemented | durable-state roadmap | SQLite local boundary only |
| System is production ready or generally secure | Not claimed | nonclaims | Outside evidence |
