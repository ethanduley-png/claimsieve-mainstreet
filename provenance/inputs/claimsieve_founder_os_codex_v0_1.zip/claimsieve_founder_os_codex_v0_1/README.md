# ClaimSieve + Main Street Founder OS — Codex Package v0.1

This package is a build-ready work order and starter implementation for using Main Street AI to operate the ClaimSieve/Main Street company itself.

## Product sentence

Main Street observes company work and proposes actions. ClaimSieve independently decides whether an exact action may execute. A separate adapter executes only a valid, current, single-use permit. Every transition is recorded.

## First vertical slice

The first external action is intentionally narrow:

> Create a GitHub issue in one approved repository.

The implementation must block repository substitution, payload mutation, stale approval, replay, missing evidence, and direct execution without a permit.

## Run

```bash
python -m unittest discover -s tests -v
python examples/demo.py
```

No network access or third-party dependency is required for the reference tests. The GitHub adapter is simulated until Codex wires the real connector behind the same interface.

## Read first

1. `CODEX_WORK_ORDER.md`
2. `docs/ARCHITECTURE.md`
3. `docs/THREAT_MODEL.md`
4. `docs/ACCEPTANCE_CRITERIA.md`
5. `AUTHORITATIVE_SCOPE.md`

## Non-claims

This package does not claim production readiness, complete mediation outside the supplied boundary, full formal verification, secure key management, distributed consensus, or proof that external providers performed an effect.
