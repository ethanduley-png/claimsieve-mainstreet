# Build and Test Report — v0.33.0

## Executed

* 140 Python tests passed.
* 18 Node tests passed.
* Source and schema gate passed.
* Portable evidence bundle verified.
* Durable vector generated and validated.
* v0.32 violating trace preserved.
* v0.33 patched trace passed.
* Provider contract gate passed 6 of 6 scenarios.
* Semantic outcome vectors passed 8 of 8.
* Inherited red team reported 52 blocked or detected, 0 bypasses, 6 limitations.
* Durable red team reported 25 blocked or detected, 0 bypasses, 4 limitations.

## Not executed

* Rust format, Clippy, build, and tests.
* Rocq compilation and assumption audit.
* Live provider tests.

See `docs/NATIVE_COMPILATION_REPORT.md` for the environment boundary.
