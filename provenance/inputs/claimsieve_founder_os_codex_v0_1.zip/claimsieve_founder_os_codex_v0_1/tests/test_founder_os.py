import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from founder_os.core import Approval, DecisionError, GitHubIssueAdapter, PermitAuthority, Policy, Proposal


class Clock:
    def __init__(self, now=1_000): self.now = now
    def __call__(self): return self.now


class FounderOSTests(unittest.TestCase):
    def setUp(self):
        self.clock = Clock()
        self.policy = Policy("founder-os.v1", frozenset({"ethanduley-png/claimsieve-mainstreet"}), permit_ttl_seconds=300)
        self.authority = PermitAuthority(self.policy, b"test-secret-not-production", self.clock)
        self.proposal = Proposal(
            proposal_id="p-1", actor_id="mainstreet", action="github.issue.create",
            repository="ethanduley-png/claimsieve-mainstreet", title="Add Founder OS vertical slice",
            body="Implement the governed issue workflow.", evidence_refs=("decision:founder-os-v0.1",),
            policy_version="founder-os.v1", created_at=900,
        )

    def approval(self, proposal=None):
        p = proposal or self.proposal
        return Approval(p.proposal_id, p.payload_hash, "ethan", 995)

    def permit(self):
        return self.authority.issue(self.proposal, self.approval())

    def test_valid_attempt(self):
        adapter = GitHubIssueAdapter(self.authority, lambda p: {"status": "confirmed", "issue_number": 1})
        result = adapter.execute(self.proposal, self.permit())
        self.assertEqual(result["outcome"], "confirmed")
        self.assertFalse(result["independently_verified"])

    def test_missing_evidence_blocked(self):
        p = Proposal(**{**self.proposal.__dict__, "evidence_refs": ()})
        with self.assertRaisesRegex(DecisionError, "MISSING_EVIDENCE"):
            self.authority.issue(p, self.approval(p))

    def test_repository_substitution_after_approval_blocked(self):
        permit = self.permit()
        changed = Proposal(**{**self.proposal.__dict__, "repository": "attacker/other"})
        adapter = GitHubIssueAdapter(self.authority, lambda p: {"status": "confirmed"})
        with self.assertRaisesRegex(DecisionError, "PAYLOAD_MISMATCH"):
            adapter.execute(changed, permit)

    def test_body_mutation_after_approval_blocked(self):
        permit = self.permit()
        changed = Proposal(**{**self.proposal.__dict__, "body": "Different body"})
        adapter = GitHubIssueAdapter(self.authority, lambda p: {"status": "confirmed"})
        with self.assertRaisesRegex(DecisionError, "PAYLOAD_MISMATCH"):
            adapter.execute(changed, permit)

    def test_replay_blocked(self):
        permit = self.permit()
        adapter = GitHubIssueAdapter(self.authority, lambda p: {"status": "confirmed"})
        adapter.execute(self.proposal, permit)
        with self.assertRaisesRegex(DecisionError, "PERMIT_REPLAY"):
            adapter.execute(self.proposal, permit)

    def test_expired_permit_blocked(self):
        permit = self.permit()
        self.clock.now = permit.expires_at + 1
        adapter = GitHubIssueAdapter(self.authority, lambda p: {"status": "confirmed"})
        with self.assertRaisesRegex(DecisionError, "PERMIT_EXPIRED"):
            adapter.execute(self.proposal, permit)

    def test_direct_execution_without_permit_blocked(self):
        adapter = GitHubIssueAdapter(self.authority, lambda p: {"status": "confirmed"})
        with self.assertRaisesRegex(DecisionError, "PERMIT_REQUIRED"):
            adapter.execute(self.proposal, None)

    def test_policy_drift_blocked(self):
        permit = self.permit()
        self.authority.policy = Policy("founder-os.v2", self.policy.allowed_repositories)
        adapter = GitHubIssueAdapter(self.authority, lambda p: {"status": "confirmed"})
        with self.assertRaisesRegex(DecisionError, "POLICY_VERSION_MISMATCH"):
            adapter.execute(self.proposal, permit)

    def test_ambiguous_provider_response_is_unknown(self):
        adapter = GitHubIssueAdapter(self.authority, lambda p: {"status": "timeout", "request_id": "x"})
        result = adapter.execute(self.proposal, self.permit())
        self.assertEqual(result["outcome"], "unknown")
        self.assertFalse(result["independently_verified"])


if __name__ == "__main__": unittest.main()
