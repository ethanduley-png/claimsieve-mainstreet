from __future__ import annotations

from dataclasses import dataclass, asdict
import hashlib
import hmac
import json
from typing import Callable, Iterable


def canonical_json(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def digest(value: object) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


@dataclass(frozen=True)
class Proposal:
    proposal_id: str
    actor_id: str
    action: str
    repository: str
    title: str
    body: str
    evidence_refs: tuple[str, ...]
    policy_version: str
    created_at: int

    def protected_payload(self) -> dict[str, object]:
        return asdict(self)

    @property
    def payload_hash(self) -> str:
        return digest(self.protected_payload())


@dataclass(frozen=True)
class Approval:
    proposal_id: str
    payload_hash: str
    approver_id: str
    approved_at: int


@dataclass(frozen=True)
class Permit:
    permit_id: str
    proposal_id: str
    payload_hash: str
    action: str
    repository: str
    policy_version: str
    issued_at: int
    expires_at: int
    signature: str

    def unsigned(self) -> dict[str, object]:
        value = asdict(self)
        value.pop("signature")
        return value


@dataclass(frozen=True)
class Policy:
    version: str
    allowed_repositories: frozenset[str]
    permit_ttl_seconds: int = 300
    max_title_length: int = 180
    max_body_length: int = 20_000


class DecisionError(ValueError):
    pass


class PermitAuthority:
    """Reference authority. Replace HMAC with existing repository key boundary where available."""

    def __init__(self, policy: Policy, secret: bytes, clock: Callable[[], int]):
        if not secret:
            raise ValueError("secret required")
        self.policy = policy
        self._secret = secret
        self._clock = clock
        self._used: set[str] = set()

    def evaluate(self, proposal: Proposal) -> tuple[bool, tuple[str, ...]]:
        reasons: list[str] = []
        if proposal.action != "github.issue.create":
            reasons.append("ACTION_NOT_ALLOWED")
        if proposal.repository not in self.policy.allowed_repositories:
            reasons.append("REPOSITORY_NOT_ALLOWED")
        if proposal.policy_version != self.policy.version:
            reasons.append("POLICY_VERSION_MISMATCH")
        if not proposal.title or len(proposal.title) > self.policy.max_title_length:
            reasons.append("INVALID_TITLE")
        if not proposal.body or len(proposal.body) > self.policy.max_body_length:
            reasons.append("INVALID_BODY")
        if not proposal.evidence_refs or any(not ref for ref in proposal.evidence_refs):
            reasons.append("MISSING_EVIDENCE")
        return not reasons, tuple(reasons)

    def issue(self, proposal: Proposal, approval: Approval) -> Permit:
        allowed, reasons = self.evaluate(proposal)
        if not allowed:
            raise DecisionError(",".join(reasons))
        if approval.proposal_id != proposal.proposal_id:
            raise DecisionError("APPROVAL_PROPOSAL_MISMATCH")
        if not hmac.compare_digest(approval.payload_hash, proposal.payload_hash):
            raise DecisionError("APPROVAL_PAYLOAD_MISMATCH")
        now = self._clock()
        permit_id = digest({"proposal_id": proposal.proposal_id, "payload_hash": proposal.payload_hash, "issued_at": now})
        unsigned = {
            "permit_id": permit_id,
            "proposal_id": proposal.proposal_id,
            "payload_hash": proposal.payload_hash,
            "action": proposal.action,
            "repository": proposal.repository,
            "policy_version": proposal.policy_version,
            "issued_at": now,
            "expires_at": now + self.policy.permit_ttl_seconds,
        }
        signature = hmac.new(self._secret, canonical_json(unsigned), hashlib.sha256).hexdigest()
        return Permit(**unsigned, signature=signature)

    def verify_and_consume(self, permit: Permit, proposal: Proposal) -> None:
        expected = hmac.new(self._secret, canonical_json(permit.unsigned()), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, permit.signature):
            raise DecisionError("INVALID_PERMIT_SIGNATURE")
        if permit.permit_id in self._used:
            raise DecisionError("PERMIT_REPLAY")
        if self._clock() > permit.expires_at:
            raise DecisionError("PERMIT_EXPIRED")
        if permit.policy_version != self.policy.version or proposal.policy_version != self.policy.version:
            raise DecisionError("POLICY_VERSION_MISMATCH")
        if permit.proposal_id != proposal.proposal_id:
            raise DecisionError("PROPOSAL_MISMATCH")
        if not hmac.compare_digest(permit.payload_hash, proposal.payload_hash):
            raise DecisionError("PAYLOAD_MISMATCH")
        if permit.action != proposal.action or permit.repository != proposal.repository:
            raise DecisionError("EXECUTION_PARAMETER_MISMATCH")
        self._used.add(permit.permit_id)


class GitHubIssueAdapter:
    def __init__(self, authority: PermitAuthority, provider: Callable[[Proposal], dict[str, object]]):
        self._authority = authority
        self._provider = provider

    def execute(self, proposal: Proposal, permit: Permit | None) -> dict[str, object]:
        if permit is None:
            raise DecisionError("PERMIT_REQUIRED")
        self._authority.verify_and_consume(permit, proposal)
        response = self._provider(proposal)
        provider_status = str(response.get("status", "unknown"))
        if provider_status == "confirmed":
            outcome = "confirmed"
        elif provider_status == "failed":
            outcome = "failed"
        else:
            outcome = "unknown"
        return {
            "proposal_id": proposal.proposal_id,
            "permit_id": permit.permit_id,
            "attempted": True,
            "provider_evidence": response,
            "outcome": outcome,
            "independently_verified": False,
        }
