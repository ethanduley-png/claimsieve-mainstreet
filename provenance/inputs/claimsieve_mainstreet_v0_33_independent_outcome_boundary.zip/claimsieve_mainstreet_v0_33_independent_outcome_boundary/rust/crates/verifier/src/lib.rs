#![forbid(unsafe_code)]

//! Offline verification for portable ClaimSieve evidence bundles.

use base64::{Engine as _, engine::general_purpose::URL_SAFE_NO_PAD};
use claimsieve_ledger::{LedgerRecord, verify_chain};
use claimsieve_protocol::{
    Decision, Evidence, Permit, Policy, Proposal, action_digest, approval_digest,
    approval_signing_subject, canonical_bytes, destination_digest, digest, display_digest,
    evidence_root, parameter_digest, proposal_digest, MAX_SAFE_INTEGER,
};
use claimsieve_runtime::verify_permit_signature;
use ed25519_dalek::{Signature, Verifier, VerifyingKey};
use serde::de::{self, MapAccess, SeqAccess, Visitor};
use serde::{Deserialize, Deserializer, Serialize};
use serde_json::Value;
use std::collections::{BTreeMap, BTreeSet};
use std::fmt;
use thiserror::Error;

/// Errors that prevent the verifier itself from processing a bundle.
#[derive(Debug, Error)]
pub enum VerifierError {
    /// JSON parsing failed.
    #[error("bundle JSON parsing failed: {0}")]
    Json(String),
}

/// Portable evidence-bundle manifest.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct BundleManifest {
    /// Release identifier.
    pub release: String,
    /// Trace identifier.
    pub trace_id: String,
    /// Canonicalization profile.
    pub canonical_profile: String,
    /// Hash algorithm.
    pub hash_algorithm: String,
    /// Signature algorithm.
    pub signature_algorithm: String,
    /// Expected ledger heads.
    pub ledger_heads: BTreeMap<String, Option<String>>,
    /// Expected ledger record counts.
    pub record_counts: BTreeMap<String, u64>,
    /// Digest of the manifest with this field omitted.
    pub bundle_digest: String,
}

/// Complete portable evidence bundle.
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct EvidenceBundle {
    /// Schema version.
    pub schema_version: String,
    /// Bundle identifier.
    pub bundle_id: String,
    /// Cross-ledger trace identifier.
    pub trace_id: String,
    /// Proposal.
    pub proposal: Proposal,
    /// Policy.
    pub policy: Policy,
    /// Evidence records.
    pub evidence: Vec<Evidence>,
    /// Kernel decision.
    pub decision: Decision,
    /// Exact post-decision campaign state committed by the decision.
    pub campaign_state: Value,
    /// Optional one-use permit.
    pub permit: Option<Permit>,
    /// Four separate signed ledgers.
    pub ledgers: BTreeMap<String, Vec<LedgerRecord>>,
    /// Signed executor, observer, and containment receipts.
    pub receipts: Vec<Value>,
    /// Verification keys, encoded as `ed25519-pub:` plus base64url.
    pub public_keys: BTreeMap<String, String>,
    /// Portable manifest.
    pub manifest: BundleManifest,
}

/// Verification result. An empty error list means the bundle verified.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct VerificationReport {
    /// Whether all checks passed.
    pub valid: bool,
    /// Stable human-readable failures.
    pub errors: Vec<String>,
}

fn decode_public_key(encoded: &str) -> Result<VerifyingKey, String> {
    let raw = encoded
        .strip_prefix("ed25519-pub:")
        .ok_or_else(|| "unsupported public-key encoding".to_owned())?;
    let bytes = URL_SAFE_NO_PAD
        .decode(raw)
        .map_err(|error| format!("invalid public-key base64: {error}"))?;
    let array: [u8; 32] = bytes
        .try_into()
        .map_err(|_| "public key must be 32 bytes".to_owned())?;
    VerifyingKey::from_bytes(&array).map_err(|error| format!("invalid public key: {error}"))
}

fn decode_signature(encoded: &str) -> Result<Signature, String> {
    let raw = encoded
        .strip_prefix("ed25519:")
        .ok_or_else(|| "unsupported signature encoding".to_owned())?;
    let bytes = URL_SAFE_NO_PAD
        .decode(raw)
        .map_err(|error| format!("invalid signature base64: {error}"))?;
    Signature::from_slice(&bytes).map_err(|error| format!("invalid signature: {error}"))
}

fn signing_message(domain: &str, value: &Value) -> Result<Vec<u8>, String> {
    let mut message = b"CLAIMSIEVE\0".to_vec();
    message.extend_from_slice(domain.as_bytes());
    message.push(0);
    message.extend_from_slice(&canonical_bytes(value).map_err(|error| error.to_string())?);
    Ok(message)
}

fn verify_value_signature(
    key: &VerifyingKey,
    domain: &str,
    unsigned: &Value,
    encoded: &str,
) -> Result<(), String> {
    let signature = decode_signature(encoded)?;
    let message = signing_message(domain, unsigned)?;
    key.verify(&message, &signature)
        .map_err(|error| format!("signature mismatch: {error}"))
}

fn public_keys(bundle: &EvidenceBundle) -> (BTreeMap<String, VerifyingKey>, Vec<String>) {
    let mut keys = BTreeMap::new();
    let mut errors = Vec::new();
    for (key_id, encoded) in &bundle.public_keys {
        match decode_public_key(encoded) {
            Ok(key) => {
                keys.insert(key_id.clone(), key);
            }
            Err(error) => errors.push(format!("public key {key_id}: {error}")),
        }
    }
    (keys, errors)
}

fn same_key_material(
    keys: &BTreeMap<String, VerifyingKey>,
    left: Option<&str>,
    right: Option<&str>,
) -> bool {
    match (left.and_then(|id| keys.get(id)), right.and_then(|id| keys.get(id))) {
        (Some(left_key), Some(right_key)) => left_key.as_bytes() == right_key.as_bytes(),
        _ => false,
    }
}

fn artifact_recorded<T: Serialize>(
    bundle: &EvidenceBundle,
    ledger_id: &str,
    record_type: &str,
    artifact: &T,
) -> Result<bool, String> {
    let artifact_value = serde_json::to_value(artifact)
        .map_err(|error| format!("artifact serialization failed: {error}"))?;
    let artifact_digest = digest(&artifact_value).map_err(|error| error.to_string())?;
    Ok(bundle
        .ledgers
        .get(ledger_id)
        .into_iter()
        .flatten()
        .any(|record| {
            record.unsigned.record_type == record_type
                && record.unsigned.payload_hash == artifact_digest
                && record.unsigned.payload == artifact_value
        }))
}

fn verify_receipt(
    receipt: &Value,
    keys: &BTreeMap<String, VerifyingKey>,
    trace_id: &str,
    permit_id: Option<&str>,
) -> Vec<String> {
    let mut errors = Vec::new();
    let Some(object) = receipt.as_object() else {
        return vec!["receipt must be a JSON object".to_owned()];
    };
    let schema = object
        .get("schema_version")
        .and_then(Value::as_str)
        .unwrap_or_default();
    let (key_field, domain, requires_execution_binding) = match schema {
        "claimsieve.executor_receipt.v1" =>
            ("executor_key_id", "executor-receipt-v1", true),
        "claimsieve.observer_receipt.v1" =>
            ("observer_key_id", "observer-receipt-v1", true),
        "claimsieve.containment_receipt.v1" =>
            ("controller_key_id", "containment-v1", false),
        _ => return vec![format!("unsupported receipt schema: {schema}")],
    };
    let Some(key_id) = object.get(key_field).and_then(Value::as_str) else {
        return vec![format!("receipt missing {key_field}")];
    };
    let Some(encoded_signature) = object.get("signature").and_then(Value::as_str) else {
        return vec!["receipt missing signature".to_owned()];
    };
    let mut unsigned_object = object.clone();
    unsigned_object.remove("signature");
    match keys.get(key_id) {
        Some(key) => {
            if let Err(error) = verify_value_signature(
                key,
                domain,
                &Value::Object(unsigned_object),
                encoded_signature,
            ) {
                errors.push(format!("invalid {schema} signature: {error}"));
            }
        }
        None => errors.push(format!("unknown receipt key: {key_id}")),
    }
    if requires_execution_binding {
        if object.get("trace_id").and_then(Value::as_str) != Some(trace_id) {
            errors.push("receipt trace mismatch".to_owned());
        }
        match permit_id {
            Some(expected)
                if object.get("permit_id").and_then(Value::as_str) == Some(expected) => {}
            _ => errors.push("receipt permit mismatch".to_owned()),
        }
    }
    errors
}

fn verify_manifest(bundle: &EvidenceBundle) -> Vec<String> {
    let mut errors = Vec::new();
    if bundle.manifest.trace_id != bundle.trace_id {
        errors.push("manifest trace mismatch".to_owned());
    }
    if bundle.manifest.canonical_profile != "claimsieve.restricted-json.v1" {
        errors.push("unsupported canonical profile".to_owned());
    }
    if bundle.manifest.hash_algorithm != "sha256" {
        errors.push("unsupported hash algorithm".to_owned());
    }
    if bundle.manifest.signature_algorithm != "ed25519" {
        errors.push("unsupported signature algorithm".to_owned());
    }
    let mut manifest_value = match serde_json::to_value(&bundle.manifest) {
        Ok(value) => value,
        Err(error) => {
            errors.push(format!("manifest serialization failed: {error}"));
            return errors;
        }
    };
    if let Some(object) = manifest_value.as_object_mut() {
        object.remove("bundle_digest");
    }
    match digest(&manifest_value) {
        Ok(expected) if expected == bundle.manifest.bundle_digest => {}
        Ok(_) => errors.push("manifest digest mismatch".to_owned()),
        Err(error) => errors.push(format!("manifest digest failed: {error}")),
    }
    for ledger_id in ["proposal", "evidence", "decision", "execution"] {
        let records = bundle.ledgers.get(ledger_id).map(Vec::as_slice).unwrap_or(&[]);
        let expected_head = records.last().map(|record| record.record_hash.clone());
        if bundle.manifest.ledger_heads.get(ledger_id) != Some(&expected_head) {
            errors.push(format!("manifest ledger head mismatch: {ledger_id}"));
        }
        let count = u64::try_from(records.len()).unwrap_or(u64::MAX);
        if bundle.manifest.record_counts.get(ledger_id) != Some(&count) {
            errors.push(format!("manifest record count mismatch: {ledger_id}"));
        }
    }
    errors
}

struct StrictJsonValue(Value);

impl<'de> Deserialize<'de> for StrictJsonValue {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        struct StrictVisitor;

        impl<'de> Visitor<'de> for StrictVisitor {
            type Value = StrictJsonValue;

            fn expecting(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
                formatter.write_str("JSON without duplicate keys or floating-point numbers")
            }

            fn visit_unit<E>(self) -> Result<Self::Value, E>
            where
                E: de::Error,
            {
                Ok(StrictJsonValue(Value::Null))
            }

            fn visit_none<E>(self) -> Result<Self::Value, E>
            where
                E: de::Error,
            {
                Ok(StrictJsonValue(Value::Null))
            }

            fn visit_bool<E>(self, value: bool) -> Result<Self::Value, E>
            where
                E: de::Error,
            {
                Ok(StrictJsonValue(Value::Bool(value)))
            }

            fn visit_i64<E>(self, value: i64) -> Result<Self::Value, E>
            where
                E: de::Error,
            {
                if value.unsigned_abs() > MAX_SAFE_INTEGER {
                    return Err(E::custom("integer outside the safe canonical range"));
                }
                Ok(StrictJsonValue(Value::Number(value.into())))
            }

            fn visit_u64<E>(self, value: u64) -> Result<Self::Value, E>
            where
                E: de::Error,
            {
                if value > MAX_SAFE_INTEGER {
                    return Err(E::custom("integer outside the safe canonical range"));
                }
                Ok(StrictJsonValue(Value::Number(value.into())))
            }

            fn visit_f64<E>(self, _value: f64) -> Result<Self::Value, E>
            where
                E: de::Error,
            {
                Err(E::custom("floating-point JSON values are forbidden"))
            }

            fn visit_str<E>(self, value: &str) -> Result<Self::Value, E>
            where
                E: de::Error,
            {
                Ok(StrictJsonValue(Value::String(value.to_owned())))
            }

            fn visit_string<E>(self, value: String) -> Result<Self::Value, E>
            where
                E: de::Error,
            {
                Ok(StrictJsonValue(Value::String(value)))
            }

            fn visit_seq<A>(self, mut sequence: A) -> Result<Self::Value, A::Error>
            where
                A: SeqAccess<'de>,
            {
                let mut values = Vec::new();
                while let Some(StrictJsonValue(value)) =
                    sequence.next_element::<StrictJsonValue>()?
                {
                    values.push(value);
                }
                Ok(StrictJsonValue(Value::Array(values)))
            }

            fn visit_map<A>(self, mut map: A) -> Result<Self::Value, A::Error>
            where
                A: MapAccess<'de>,
            {
                let mut object = serde_json::Map::new();
                while let Some(key) = map.next_key::<String>()? {
                    if object.contains_key(&key) {
                        return Err(de::Error::custom(format!(
                            "duplicate JSON key: {key}"
                        )));
                    }
                    let StrictJsonValue(value) = map.next_value::<StrictJsonValue>()?;
                    object.insert(key, value);
                }
                Ok(StrictJsonValue(Value::Object(object)))
            }
        }

        deserializer.deserialize_any(StrictVisitor)
    }
}

/// Parse with duplicate-key and float rejection, then verify an evidence bundle.
pub fn verify_json(input: &str) -> Result<VerificationReport, VerifierError> {
    let mut deserializer = serde_json::Deserializer::from_str(input);
    let StrictJsonValue(value) = StrictJsonValue::deserialize(&mut deserializer)
        .map_err(|error| VerifierError::Json(error.to_string()))?;
    deserializer
        .end()
        .map_err(|error| VerifierError::Json(error.to_string()))?;
    let bundle: EvidenceBundle = serde_json::from_value(value)
        .map_err(|error| VerifierError::Json(error.to_string()))?;
    Ok(verify_bundle(&bundle))
}

/// Verify a decoded evidence bundle without relying on internal databases.
#[must_use]
pub fn verify_bundle(bundle: &EvidenceBundle) -> VerificationReport {
    let mut errors = Vec::new();
    if bundle.schema_version != "claimsieve.evidence_bundle.v1" {
        errors.push("unsupported evidence bundle schema".to_owned());
    }
    if bundle.trace_id != bundle.proposal.trace_id {
        errors.push("bundle trace does not match proposal".to_owned());
    }
    if bundle.decision.trace_id != bundle.proposal.trace_id {
        errors.push("decision trace does not match proposal".to_owned());
    }
    if bundle.proposal.tenant_id != bundle.policy.tenant_id {
        errors.push("proposal tenant does not match policy".to_owned());
    }
    if !bundle
        .policy
        .allowed_principals
        .iter()
        .any(|principal| principal == &bundle.proposal.principal)
    {
        errors.push("proposal principal is not allowed by policy".to_owned());
    }
    match digest(&bundle.campaign_state) {
        Ok(value) if value == bundle.decision.campaign_state_digest => {}
        Ok(_) => errors.push("decision campaign-state digest mismatch".to_owned()),
        Err(error) => errors.push(format!("campaign-state digest failed: {error}")),
    }
    if bundle
        .campaign_state
        .get("campaign_id")
        .and_then(Value::as_str)
        != Some(bundle.proposal.campaign_id.as_str())
    {
        errors.push("campaign state identifier mismatch".to_owned());
    }
    if bundle.permit.is_some()
        && bundle
            .campaign_state
            .get("status")
            .and_then(Value::as_str)
            != Some("ACTIVE")
    {
        errors.push("permit issued for non-active campaign state".to_owned());
    }
    match proposal_digest(&bundle.proposal) {
        Ok(value) if value == bundle.decision.proposal_digest => {}
        Ok(_) => errors.push("decision proposal digest mismatch".to_owned()),
        Err(error) => errors.push(format!("proposal digest failed: {error}")),
    }
    match approval_digest(&bundle.proposal) {
        Ok(value) if value == bundle.decision.approval_digest => {}
        Ok(_) => errors.push("decision human approval digest mismatch".to_owned()),
        Err(error) => errors.push(format!("decision approval digest failed: {error}")),
    }
    match digest(&bundle.policy) {
        Ok(value) if value == bundle.decision.policy_digest => {}
        Ok(_) => errors.push("decision policy digest mismatch".to_owned()),
        Err(error) => errors.push(format!("policy digest failed: {error}")),
    }
    match evidence_root(&bundle.evidence) {
        Ok(value) if value == bundle.decision.evidence_root => {}
        Ok(_) => errors.push("decision evidence root mismatch".to_owned()),
        Err(error) => errors.push(format!("decision evidence root failed: {error}")),
    }

    let evidence_digests = bundle
        .evidence
        .iter()
        .map(digest)
        .collect::<Result<Vec<_>, _>>();
    match evidence_digests {
        Ok(digests) => {
            let available = digests.iter().cloned().collect::<BTreeSet<_>>();
            let referenced = bundle
                .proposal
                .evidence_refs
                .iter()
                .cloned()
                .collect::<BTreeSet<_>>();
            if available.len() != digests.len()
                || referenced.len() != bundle.proposal.evidence_refs.len()
                || available != referenced
            {
                errors.push(
                    "proposal evidence references do not exactly match the snapshot"
                        .to_owned(),
                );
            }
        }
        Err(error) => errors.push(format!("evidence digest failed: {error}")),
    }

    let (keys, key_errors) = public_keys(bundle);
    errors.extend(key_errors);

    if let Some(approval) = &bundle.proposal.approval {
        if approval.schema_version != "claimsieve.approval.v1" {
            errors.push("unsupported human approval schema".to_owned());
        }
        if !approval.approver.starts_with("spiffe://") {
            errors.push("human approval identity invalid".to_owned());
        }
        if !bundle
            .policy
            .allowed_approver_identities
            .iter()
            .any(|identity| identity == &approval.approver)
        {
            errors.push("human approval identity not allowed by policy".to_owned());
        }
        match proposal_digest(&bundle.proposal) {
            Ok(expected) if expected == approval.proposal_digest => {}
            Ok(_) => errors.push("human approval proposal digest mismatch".to_owned()),
            Err(error) => errors.push(format!("human approval proposal digest failed: {error}")),
        }
        match display_digest(&bundle.proposal) {
            Ok(expected) if expected == approval.display_digest => {}
            Ok(_) => errors.push("human approval display digest mismatch".to_owned()),
            Err(error) => errors.push(format!("human approval display digest failed: {error}")),
        }
        if approval.approved_at_seq > bundle.decision.decided_at_seq
            || approval.expires_at_seq < bundle.decision.decided_at_seq
            || approval.expires_at_seq < approval.approved_at_seq
        {
            errors.push("human approval sequence invalid".to_owned());
        }
        if !bundle
            .policy
            .allowed_approver_key_ids
            .iter()
            .any(|key_id| key_id == &approval.approver_key_id)
        {
            errors.push("human approval key not allowed by policy".to_owned());
        }
        match (keys.get(&approval.approver_key_id), approval_signing_subject(approval)) {
            (Some(key), Ok(subject)) => {
                if verify_value_signature(key, "approval-v1", &subject, &approval.signature).is_err() {
                    errors.push("human approval signature invalid".to_owned());
                }
            }
            (None, _) => errors.push("human approval key missing".to_owned()),
            (_, Err(error)) => errors.push(format!("human approval subject failed: {error}")),
        }
    }

    if let Some(permit) = &bundle.permit {
        match keys.get(&permit.authority_key_id) {
            Some(key) => {
                if let Err(error) = verify_permit_signature(permit, key) {
                    errors.push(format!("permit signature invalid: {error}"));
                }
            }
            None => errors.push("permit authority key missing".to_owned()),
        }
        let bindings = [
            ("trace_id", permit.trace_id.clone(), bundle.proposal.trace_id.clone()),
            ("tenant_id", permit.tenant_id.clone(), bundle.proposal.tenant_id.clone()),
            (
                "campaign_id",
                permit.campaign_id.clone(),
                bundle.proposal.campaign_id.clone(),
            ),
            ("principal", permit.principal.clone(), bundle.proposal.principal.clone()),
        ];
        for (name, actual, expected) in bindings {
            if actual != expected {
                errors.push(format!("permit binding mismatch: {name}"));
            }
        }
        let derived = [
            ("proposal_digest", proposal_digest(&bundle.proposal), &permit.proposal_digest),
            ("action_digest", action_digest(&bundle.proposal), &permit.action_digest),
            (
                "destination_digest",
                destination_digest(&bundle.proposal),
                &permit.destination_digest,
            ),
            (
                "parameter_digest",
                parameter_digest(&bundle.proposal),
                &permit.parameter_digest,
            ),
            ("policy_digest", digest(&bundle.policy), &permit.policy_digest),
            ("evidence_root", evidence_root(&bundle.evidence), &permit.evidence_root),
            ("decision_digest", digest(&bundle.decision), &permit.decision_digest),
        ];
        for (name, result, actual) in derived {
            match result {
                Ok(expected) if expected == *actual => {}
                Ok(_) => errors.push(format!("permit binding mismatch: {name}")),
                Err(error) => errors.push(format!("permit {name} derivation failed: {error}")),
            }
        }
        match approval_digest(&bundle.proposal) {
            Ok(value) if value == permit.approval_digest => {}
            Ok(_) => errors.push("permit binding mismatch: approval_digest".to_owned()),
            Err(error) => errors.push(format!("approval digest failed: {error}")),
        }
        if permit.max_uses != 1 {
            errors.push("permit max_uses must equal one".to_owned());
        }
        if permit.valid_from_seq != bundle.decision.decided_at_seq {
            errors.push("permit binding mismatch: valid_from_seq".to_owned());
        }
        match permit.expires_at_seq.checked_sub(permit.valid_from_seq) {
            Some(duration) if (1..=5).contains(&duration) => {}
            _ => errors.push("permit validity window invalid".to_owned()),
        }
    }

    for ledger_id in ["proposal", "evidence", "decision", "execution"] {
        let records = bundle.ledgers.get(ledger_id).map(Vec::as_slice).unwrap_or(&[]);
        if let Err(chain_errors) = verify_chain(records, ledger_id, &keys) {
            errors.extend(
                chain_errors
                    .into_iter()
                    .map(|error| format!("{ledger_id} ledger: {error}")),
            );
        }
        if !records
            .iter()
            .any(|record| record.unsigned.trace_id == bundle.trace_id)
        {
            errors.push(format!("missing trace in {ledger_id} ledger"));
        }
    }

    for (ledger_id, record_type, label, recorded) in [
        (
            "proposal",
            "PROPOSAL_SUBMITTED",
            "proposal",
            artifact_recorded(bundle, "proposal", "PROPOSAL_SUBMITTED", &bundle.proposal),
        ),
        (
            "decision",
            "DECISION_RECORDED",
            "decision",
            artifact_recorded(bundle, "decision", "DECISION_RECORDED", &bundle.decision),
        ),
    ] {
        match recorded {
            Ok(true) => {}
            Ok(false) => errors.push(format!(
                "{label} is not recorded in the {ledger_id} ledger as {record_type}"
            )),
            Err(error) => errors.push(format!("{label} ledger binding failed: {error}")),
        }
    }
    for item in &bundle.evidence {
        match artifact_recorded(bundle, "evidence", "EVIDENCE_RECORDED", item) {
            Ok(true) => {}
            Ok(false) => errors.push(
                "evidence item is not recorded in the evidence ledger".to_owned(),
            ),
            Err(error) => errors.push(format!("evidence ledger binding failed: {error}")),
        }
    }
    if let Some(permit) = &bundle.permit {
        match artifact_recorded(bundle, "decision", "PERMIT_ISSUED", permit) {
            Ok(true) => {}
            Ok(false) => errors.push(
                "permit is not recorded in the decision ledger".to_owned(),
            ),
            Err(error) => errors.push(format!("permit ledger binding failed: {error}")),
        }
    }

    let mut reserved = BTreeSet::new();
    let mut matching_reservations: Vec<&Value> = Vec::new();
    if let Some(execution) = bundle.ledgers.get("execution") {
        for record in execution {
            if record.unsigned.record_type == "PERMIT_RESERVED" {
                if let Some(reserved_permit_id) = record
                    .unsigned
                    .payload
                    .get("permit_id")
                    .and_then(Value::as_str)
                {
                    if !reserved.insert(reserved_permit_id.to_owned()) {
                        errors.push(format!(
                            "duplicate permit reservation: {reserved_permit_id}"
                        ));
                    }
                    if bundle
                        .permit
                        .as_ref()
                        .is_some_and(|permit| permit.permit_id == reserved_permit_id)
                    {
                        matching_reservations.push(&record.unsigned.payload);
                    }
                }
            }
        }
    }

    let permit_id = bundle.permit.as_ref().map(|permit| permit.permit_id.as_str());
    for receipt in &bundle.receipts {
        errors.extend(verify_receipt(receipt, &keys, &bundle.trace_id, permit_id));
        let record_type = match receipt
            .get("schema_version")
            .and_then(Value::as_str)
        {
            Some("claimsieve.executor_receipt.v1") => Some("EXECUTOR_RECEIPT"),
            Some("claimsieve.observer_receipt.v1") => Some("OBSERVER_RECEIPT"),
            Some("claimsieve.containment_receipt.v1") => Some("CONTAINMENT_RECEIPT"),
            _ => None,
        };
        if let Some(record_type) = record_type {
            match artifact_recorded(bundle, "execution", record_type, receipt) {
                Ok(true) => {}
                Ok(false) => errors.push(
                    "signed receipt is not recorded in the execution ledger".to_owned(),
                ),
                Err(error) => errors.push(format!("receipt ledger binding failed: {error}")),
            }
        }
    }

    if let Some(permit) = &bundle.permit {
        if !bundle.receipts.is_empty() && matching_reservations.len() != 1 {
            errors.push("executed permit must have exactly one reservation".to_owned());
        }
        if let Some(reservation) = matching_reservations.first() {
            if reservation.get("action_digest").and_then(Value::as_str)
                != Some(permit.action_digest.as_str())
            {
                errors.push("reservation action digest mismatch".to_owned());
            }
        }

        let executor_receipts = bundle
            .receipts
            .iter()
            .filter(|receipt| {
                receipt.get("schema_version").and_then(Value::as_str)
                    == Some("claimsieve.executor_receipt.v1")
            })
            .collect::<Vec<_>>();
        let observer_receipts = bundle
            .receipts
            .iter()
            .filter(|receipt| {
                receipt.get("schema_version").and_then(Value::as_str)
                    == Some("claimsieve.observer_receipt.v1")
            })
            .collect::<Vec<_>>();
        if !bundle.receipts.is_empty()
            && (executor_receipts.len() != 1 || observer_receipts.len() != 1)
        {
            errors.push(
                "executed permit requires one executor and one observer receipt"
                    .to_owned(),
            );
        }
        if let Some(executor_receipt) = executor_receipts.first() {
            if executor_receipt.get("action_digest").and_then(Value::as_str)
                != Some(permit.action_digest.as_str())
            {
                errors.push("executor receipt action digest mismatch".to_owned());
            }
            if let Some(reservation) = matching_reservations.first() {
                if executor_receipt
                    .get("reservation_id")
                    .and_then(Value::as_str)
                    != reservation.get("reservation_id").and_then(Value::as_str)
                {
                    errors.push("executor receipt reservation mismatch".to_owned());
                }
            }
        }
        if let Some(observer_receipt) = observer_receipts.first() {
            let reconciliation = observer_receipt
                .get("reconciliation")
                .and_then(Value::as_str);
            let observed = observer_receipt
                .get("observed_action_digest")
                .and_then(Value::as_str);
            match digest(&bundle.proposal.action) {
                Ok(exact_action_digest) => match reconciliation {
                    Some("CONFIRMED_SUCCESS")
                        if observed != Some(exact_action_digest.as_str()) =>
                    {
                        errors.push(
                            "successful observation does not match authorized action"
                                .to_owned(),
                        );
                    }
                    Some("DIVERGENT_EFFECT")
                        if observed.is_none()
                            || observed == Some(exact_action_digest.as_str()) =>
                    {
                        errors.push(
                            "divergent observation lacks a divergent action digest"
                                .to_owned(),
                        );
                    }
                    Some("CONFIRMED_FAILURE") | Some("OUTCOME_UNKNOWN")
                        if observed.is_some() =>
                    {
                        errors.push(
                            "non-observed outcome unexpectedly contains an action digest"
                                .to_owned(),
                        );
                    }
                    _ => {}
                },
                Err(error) => errors.push(format!(
                    "authorized action digest failed: {error}"
                )),
            }
        }
        if let (Some(executor_receipt), Some(observer_receipt)) =
            (executor_receipts.first(), observer_receipts.first())
        {
            let status = executor_receipt
                .get("provider_status")
                .and_then(Value::as_str);
            let reconciliation = observer_receipt
                .get("reconciliation")
                .and_then(Value::as_str);
            let compatible = matches!(
                (status, reconciliation),
                (Some("accepted"), Some("CONFIRMED_SUCCESS"))
                    | (Some("accepted"), Some("DIVERGENT_EFFECT"))
                    | (Some("accepted"), Some("OUTCOME_UNKNOWN"))
                    | (Some("rejected"), Some("CONFIRMED_FAILURE"))
                    | (Some("timeout_unknown"), Some("OUTCOME_UNKNOWN"))
            );
            if !compatible {
                errors.push(
                    "provider status and observer reconciliation disagree".to_owned(),
                );
            }
        }
    }

    let mut roles = BTreeMap::<String, String>::new();
    for ledger_id in ["proposal", "evidence", "decision", "execution"] {
        let writer_ids = bundle
            .ledgers
            .get(ledger_id)
            .into_iter()
            .flatten()
            .map(|record| record.unsigned.writer_key_id.clone())
            .collect::<BTreeSet<_>>();
        if writer_ids.len() == 1 {
            if let Some(writer_id) = writer_ids.into_iter().next() {
                roles.insert(format!("ledger:{ledger_id}"), writer_id);
            }
        } else {
            errors.push(format!(
                "{ledger_id} ledger must use exactly one writer security role"
            ));
        }
    }
    if let Some(approval) = &bundle.proposal.approval {
        roles.insert(
            "human-approval".to_owned(),
            approval.approver_key_id.clone(),
        );
    }
    if let Some(permit) = &bundle.permit {
        roles.insert(
            "permit-authority".to_owned(),
            permit.authority_key_id.clone(),
        );
    }
    for receipt in &bundle.receipts {
        for (field, role) in [
            ("executor_key_id", "executor"),
            ("observer_key_id", "observer"),
            ("controller_key_id", "containment"),
        ] {
            if let Some(key_id) = receipt.get(field).and_then(Value::as_str) {
                roles.insert(role.to_owned(), key_id.to_owned());
            }
        }
    }
    let role_items = roles.iter().collect::<Vec<(&String, &String)>>();
    for (index, &(left_role, left_id)) in role_items.iter().enumerate() {
        if !keys.contains_key(left_id.as_str()) {
            errors.push(format!(
                "missing key for security role {left_role}: {left_id}"
            ));
        }
        for &(right_role, right_id) in role_items.iter().skip(index + 1) {
            if same_key_material(
                &keys,
                Some(left_id.as_str()),
                Some(right_id.as_str()),
            ) {
                errors.push(format!(
                    "security role key material reused: {left_role} and {right_role}"
                ));
            }
        }
    }

    errors.extend(verify_manifest(bundle));
    errors.sort();
    errors.dedup();
    VerificationReport {
        valid: errors.is_empty(),
        errors,
    }
}

#[cfg(test)]
mod tests {
    use super::verify_json;

    #[test]
    fn python_generated_vector_verifies() {
        let input = include_str!("../../../../vectors/valid_evidence_bundle.json");
        let result = verify_json(input);
        assert!(result.is_ok());
        if let Ok(report) = result {
            assert!(report.valid, "{:?}", report.errors);
        }
    }

    #[test]
    fn tampered_vector_is_rejected() {
        let input = include_str!("../../../../vectors/valid_evidence_bundle.json");
        let tampered = input.replace("Would you like", "You must");
        let result = verify_json(&tampered);
        assert!(result.is_ok());
        if let Ok(report) = result {
            assert!(!report.valid);
        }
    }

    #[test]
    fn forged_human_approval_is_rejected() {
        let input = include_str!("../../../../vectors/valid_evidence_bundle.json");
        let tampered = input.replace(
            "spiffe://mainstreet.local/tenant-demo/human/owner",
            "spiffe://attacker.invalid/forged",
        );
        let result = verify_json(&tampered);
        assert!(result.is_ok());
        if let Ok(report) = result {
            assert!(!report.valid);
            assert!(report.errors.iter().any(|error| error.contains("human approval")));
        }
    }

    #[test]
    fn duplicate_json_keys_are_rejected() {
        let input = r#"{"schema_version":"claimsieve.evidence_bundle.v1","schema_version":"evil"}"#;
        assert!(verify_json(input).is_err());
    }

    #[test]
    fn floating_point_json_is_rejected() {
        let input = r#"{"schema_version":"claimsieve.evidence_bundle.v1","value":1.25}"#;
        assert!(verify_json(input).is_err());
    }

    #[test]
    fn unsafe_integer_json_is_rejected() {
        let input = r#"{"schema_version":"claimsieve.evidence_bundle.v1","value":9007199254740992}"#;
        assert!(verify_json(input).is_err());
    }
}
