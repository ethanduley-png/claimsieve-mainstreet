# Architecture

```text
Founder / observer
       |
       v
Main Street Founder OS
  observe -> summarize -> propose
       |
       v
ClaimSieve decision boundary
  policy + evidence + authority + state
       |
       +---- block / needs approval
       |
       v
Human approval bound to exact hash
       |
       v
ClaimSieve short-lived single-use permit
       |
       v
GitHub adapter (replaceable executor)
       |
       v
Attempt receipt + independent observation/reconciliation
       |
       v
Proposal / Evidence / Decision / Execution ledgers
```

## Trust boundaries

1. The proposal runtime is untrusted for authority.
2. Human approval is meaningful only when bound to the exact payload.
3. ClaimSieve is trusted for the modeled decision and permit transition, not for evidence truth outside its boundary.
4. The adapter is trusted to enforce permit matching, not to certify its own success conclusively.
5. External provider state must be observed or reconciled.

## Ledger roles

- Proposal ledger: what was requested.
- Evidence ledger: what references were supplied.
- Decision ledger: policy result, approval, and permit lifecycle.
- Execution ledger: attempts, provider response, observations, and final classification.

No ledger entry overwrites history.
