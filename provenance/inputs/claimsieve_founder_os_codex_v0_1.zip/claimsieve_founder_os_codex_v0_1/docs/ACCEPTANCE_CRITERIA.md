# Acceptance Criteria

## Functional

- Valid proposal with evidence can be approved, permitted, and attempted.
- Missing evidence is denied.
- Exact payload mutation is denied at execution.
- Repository mutation is denied.
- Expired permit is denied.
- Replayed permit is denied.
- Direct execution without a permit is denied.
- Ambiguous provider response becomes `unknown`, not `confirmed`.

## Architecture

- One permit issuer.
- One live adapter route.
- Proposal layer cannot issue authority.
- Adapter does not decide policy.
- Outcome truth is not delegated solely to executor output.

## Evidence

`BUILD_REPORT.md` must list:

- commit tested;
- environment;
- exact commands;
- test totals;
- failed/skipped tests;
- artifact hashes;
- remaining limitations.
