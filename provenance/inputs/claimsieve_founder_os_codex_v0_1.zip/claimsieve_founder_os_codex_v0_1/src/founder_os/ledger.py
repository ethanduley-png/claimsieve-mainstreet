from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


class HashChainLedger:
    """Append-only reference ledger. Host-level rollback remains a documented limitation."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _last_hash(self) -> str:
        if not self.path.exists():
            return "0" * 64
        last = "0" * 64
        with self.path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    last = json.loads(line)["entry_hash"]
        return last

    def append(self, kind: str, payload: dict[str, Any]) -> str:
        previous = self._last_hash()
        protected = {"kind": kind, "payload": payload, "previous_hash": previous}
        encoded = json.dumps(protected, sort_keys=True, separators=(",", ":")).encode()
        entry_hash = hashlib.sha256(encoded).hexdigest()
        record = {**protected, "entry_hash": entry_hash}
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, sort_keys=True) + "\n")
        return entry_hash
