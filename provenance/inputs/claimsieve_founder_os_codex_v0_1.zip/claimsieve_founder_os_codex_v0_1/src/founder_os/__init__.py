"""Founder OS governed-action reference implementation."""
