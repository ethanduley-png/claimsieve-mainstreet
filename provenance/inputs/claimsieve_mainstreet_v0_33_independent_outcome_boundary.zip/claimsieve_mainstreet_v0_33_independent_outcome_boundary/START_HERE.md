# Start Here — MainStreet AI + ClaimSieve v0.33.0

## Independent Outcome Boundary

This package is an adversarial engineering release. It is organized around one reproduced invariant violation, one trusted-computing-base reduction, one provider-contract-derived unknown-outcome test, and an explicit semantic divergence audit.

Do not begin by reading the architecture narrative. Begin by reproducing the evidence.

## Fifteen-minute review path

```bash
cat VERSION
cat evidence/V032_INVARIANT_VIOLATION_TRACE.json
PYTHONPATH=python python3 evidence/V033_PATCHED_TRACE_PROBE.py
PYTHONPATH=python python3 scripts/provider_contract_gate.py
PYTHONPATH=python python3 scripts/semantic_divergence_gate.py
python3 scripts/source_gate.py
```

Then run all executable gates:

```bash
./scripts/test_all.sh
```

To attempt the native toolchains explicitly:

```bash
./scripts/compile_native.sh
```

Exit code `2` means one or both native toolchains are unavailable. It does not mean they compiled.

## What failed in v0.32

A compromised executor could produce a correctly signed but semantically false `rejected` receipt. When no independent provider record existed, the v0.32 observer converted that executor claim into `CONFIRMED_FAILURE`. The result violated both the unknown-outcome rule and the independent-observation rule.

See:

* `docs/CONCRETE_INVARIANT_VIOLATION.md`
* `evidence/V032_INVARIANT_VIOLATION_PROBE.py`
* `evidence/V032_INVARIANT_VIOLATION_TRACE.json`

## What changed

The observer no longer uses executor receipts to establish terminal outcomes. Executor receipts remain audit evidence only. Terminal classification now depends on independently readable provider evidence, and contradictory provider evidence remains `OUTCOME_UNKNOWN` with containment.

See:

* `docs/SMALLEST_TCB_REMOVAL.md`
* `docs/adr/ADR-005-independent-outcome-authority.md`
* `evidence/V033_PATCHED_TRACE.json`

## Provider contract boundary

The release contains an executable offline model of Stripe's published API v1 POST idempotency and error semantics. It tests exact same-dispatch transport replay, mutation rejection, retention expiry, cached 500 uncertainty, validation behavior, and ClaimSieve revocation/binding guards.

This is not a credentialed live Stripe integration and creates no external effects.

See:

* `research/stripe_idempotency_contract.json`
* `scripts/provider_contract_gate.py`
* `docs/STRIPE_PROVIDER_CONTRACT_TEST.md`

## Native assurance boundary

Rust and Rocq source are present. They were not compiled in the originating environment because `cargo`, `rustc`, `rocq`, and `coqc` were absent and no usable container runtime or connected GitHub repository was available.

The package therefore makes no claim of Rust compilation, Rust enforcement parity, Rocq proof acceptance, or Rocq assumption audit.

See:

* `docs/NATIVE_COMPILATION_REPORT.md`
* `docs/RUST_IMPLEMENTATION_REPORT.md`
* `docs/ROCQ_ASSURANCE_REPORT.md`
* `evidence/NATIVE_COMPILATION_ATTEMPT.txt`

## Review posture

Try to falsify the release. The highest-value review questions are:

1. Can terminal outcome still be influenced by executor-controlled state through an indirect path?
2. Can a transport replay escape the same reservation, request, endpoint, account, authority, retention, or replay-budget binding?
3. Does Rust encode a different wire protocol or state transition than executed Python?
4. Does Rocq prove a weaker property than the implementation or documentation imply?
5. Can contradictory provider evidence be coerced into a terminal answer?
6. Can state recovery silently create a new logical action?
