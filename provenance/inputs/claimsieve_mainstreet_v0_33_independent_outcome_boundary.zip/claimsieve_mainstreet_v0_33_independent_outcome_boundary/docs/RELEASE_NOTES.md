# Release Notes — 0.33.0 Independent Outcome Boundary

## Breaking semantic correction

Executor receipts no longer establish terminal outcome. Systems that previously treated a signed executor `rejected` status as confirmed failure must migrate to independent provider reconciliation.

## Added

* preserved v0.32 invariant-violation trace;
* patched v0.33 trace;
* provider-only outcome classifier;
* contradictory-provider-evidence containment;
* offline Stripe idempotency contract snapshot and gate;
* bounded same-dispatch transport replay model;
* canonical eight-case outcome vector set;
* semantic divergence report;
* explicit native compilation attempt script;
* Rust source split between executor and independent observer;
* Rocq statements for executor-independent outcome and replay guards;
* updated review and Codex handoff materials.

## Changed

* `I-032A` distinguishes a new logical action from a same-dispatch transport replay.
* `I-032B` defines the strict replay guard.
* `I-033B` makes independent provider evidence the terminal authority.
* `I-033C` keeps contradictory provider evidence unknown.
* durable red-team expectations now match the independent-outcome boundary.

## Known incompatibility

Rust observer receipts remain v1-shaped while Python and schemas use v2. This release does not claim Rust wire compatibility.

## Native status

Rust and Rocq toolchains were unavailable in the originating environment. No native pass is claimed.
