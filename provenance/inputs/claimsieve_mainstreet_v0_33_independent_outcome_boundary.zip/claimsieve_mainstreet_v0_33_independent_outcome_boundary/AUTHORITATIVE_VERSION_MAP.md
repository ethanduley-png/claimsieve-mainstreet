# Authoritative Version Map

| Authority | Location | Current identity | Status |
|---|---|---|---|
| Release identity | `VERSION` | `0.33.0` | Authoritative |
| Release name | `README.md` | Independent Outcome Boundary | Authoritative |
| Executed reference semantics | `python/claimsieve_ref/` | v0.33 | Implemented and executed |
| Customer proposal boundary | `mainstreet/` | 0.33.0 | Implemented and executed |
| Protocol schemas | `schemas/` | mixed stable and v2 durable receipts | Executed validation |
| Provider contract fixture | `research/stripe_idempotency_contract.json` | Stripe API v1 snapshot dated 2026-08-01 | Offline contract model |
| Rust enforcement candidate | `rust/` | workspace 0.33.0 | Source present, not compiled here |
| Rocq model | `rocq/DurableState.v` | v0.33 narrow model | Source present, not compiled here |
| Historical durable baseline | `docs/V0_32_*` | v0.32.0 | Lineage only |
| Historical trust-root baseline | archived v0.31 materials | v0.31.0 | Lineage only |

## Authority rule

Documentation does not override executable behavior. Python is the only executed semantic reference in this environment. Rust and Rocq are candidate implementations and models until their native toolchains run successfully and differential tests are executed.

## Release progression

* v0.31 repaired trust-root and role-collapse failures.
* v0.32 added a local crash-durable campaign and reservation boundary.
* v0.33 removes executor claims from the terminal-outcome trust path and introduces contract-derived transport replay semantics.
