# Authoritative Scope

## Controlling objective

Build one end-to-end governed workflow for the founders' own company:

1. Observe a candidate work item.
2. Produce a structured proposal.
3. Evaluate it against named policy and evidence.
4. Require an exact human approval when policy requires it.
5. Issue a short-lived, single-use permit.
6. Execute through a separate adapter.
7. Record an outcome without treating the executor's assertion as independent truth.

## In scope

- GitHub issue creation in an allowlisted repository.
- Local task and document proposals.
- Exact payload hashing.
- Evidence references.
- Human approval binding.
- Permit expiry and single use.
- Append-only JSONL reference ledgers.
- Deterministic tests and adversarial mutations.

## Out of scope

- Pull request merge.
- Branch protection changes.
- Email sending.
- Calendar writes.
- Payments, tax, legal filing, or production customer actions.
- Autonomous action without a policy-defined path.
- Multi-tenant deployment.
- Network consensus.
- Claims of provider-side success without observation or reconciliation.

## Authority rule

Main Street and any model/runtime may propose. They may not issue permits, mark outcomes independently verified, or invoke a live adapter directly.
