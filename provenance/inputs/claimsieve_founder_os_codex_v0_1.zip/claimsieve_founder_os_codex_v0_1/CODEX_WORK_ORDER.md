# CODEX WORK ORDER — Founder OS v0.1

## Mission

Extend the existing ClaimSieve + Main Street repository with a founder-operated vertical slice. Do not replace the current kernel, ledgers, contracts, or release gates when equivalent components already exist. Reuse and adapt them.

## Required first output

Before changing code, print:

1. detected repository root;
2. current branch and commit;
3. controlling ClaimSieve/Main Street version files found;
4. existing test commands;
5. exact modules you will reuse;
6. any conflict between this package and the repository's current architecture.

If the repository already has a stronger implementation, preserve it and map this work order onto it instead of introducing a parallel framework.

## Product behavior

Create a Founder OS workspace that shows:

- proposed GitHub issues;
- local research/document proposals;
- requested approvals;
- allowed, blocked, expired, replayed, and uncertain outcomes;
- evidence and receipts for each action.

The ordinary interface may say:

- Ready for review
- Approved
- Cannot execute
- Completed
- Outcome uncertain

Detailed reason codes remain available in an inspector.

## First governed action

`github.issue.create`

Required fields:

- proposal_id
- actor_id
- repository
- title
- body
- evidence_refs
- policy_version
- created_at
- payload_hash

Policy v1:

- repository must be allowlisted;
- title and body must be nonempty and within configured limits;
- at least one evidence reference is required;
- human approval is required;
- approval must bind proposal ID and exact payload hash;
- permit lifetime is at most five minutes;
- permit is single use;
- actual execution parameters must exactly match the permit;
- failed or ambiguous provider results must not be recorded as independently verified success.

## Separation requirements

- Proposal code cannot import private signing/permit issuance functions.
- Main Street cannot manufacture a valid permit.
- The adapter accepts a verified permit object, not an untrusted boolean.
- No alternate live execution route is allowed.
- Outcome recording must distinguish `attempted`, `confirmed`, `failed`, and `unknown`.
- Executor receipts are evidence, not sole terminal outcome authority.

## Deliverables

1. Founder OS API or service layer integrated into the existing app.
2. GitHub issue proposal screen or command.
3. ClaimSieve policy and permit path.
4. Separate execution adapter.
5. Inspector/receipt view.
6. Deterministic unit and conformance tests.
7. Five adversarial demonstrations.
8. Updated architecture and threat model.
9. Clean build instructions.
10. `BUILD_REPORT.md` containing exact commands and results.

## Mandatory adversarial tests

1. Change repository after approval: block.
2. Change title/body after approval: block.
3. Reuse permit: block.
4. Execute after expiry: block.
5. Call adapter without permit: block.
6. Missing evidence: block before approval.
7. Executor says success but observation is absent: outcome remains unknown/unconfirmed.
8. Policy version changes after approval: block or require re-adjudication.

## Acceptance gate

Do not mark complete unless:

- all existing tests still pass;
- all new tests pass from a clean checkout;
- there is exactly one live issue-creation path;
- no secret or private key is committed;
- README contains a five-minute demo;
- known limitations are explicit;
- generated artifacts have hashes;
- a reviewer can reproduce a permit mutation failure.

## Implementation discipline

- Python 3.11+.
- Prefer standard library unless the existing repository already uses a dependency.
- Deterministic tests: no wall clock, network, or random dependency without injection.
- Do not silently weaken a policy to make tests pass.
- Do not claim Rocq correspondence until theorem, schema, implementation, and conformance trace are explicitly linked.
- Preserve provider neutrality. GitHub is the first adapter, not embedded authority.

## Stop conditions

Stop and report rather than improvising when:

- two components can issue executable permits;
- the current repository contradicts the supplied invariant;
- live execution bypasses ClaimSieve;
- an existing release gate fails;
- the implementation would require committing credentials;
- outcome truth cannot be represented without inventing certainty.
