# Codex Handoff — v0.33.0 Independent Outcome Boundary

## Mission

Treat the release as a falsifiable candidate. Do not extend it until the existing evidence is reproduced.

The immediate work is not feature development. It is to find semantic divergence across the executed Python reference, Rust source, Rocq model, JSON schemas, and written invariants.

## Reproduction sequence

```bash
cat VERSION
PYTHONPATH=python python3 evidence/V033_PATCHED_TRACE_PROBE.py
PYTHONPATH=python python3 scripts/provider_contract_gate.py
PYTHONPATH=python python3 scripts/semantic_divergence_gate.py
./scripts/test_all.sh
```

Then attempt:

```bash
./scripts/compile_native.sh
```

Preserve all output. If a toolchain is unavailable, report `BLOCKED_BY_ENVIRONMENT`; do not translate that into pass or fail.

## First work order

### Target

Resolve or falsify `REM-DIV-001`:

> Rust observer receipts remain v1-shaped while executed Python and the JSON schema use v2 fields for reservation, campaign, provider-record digest, and conflict binding.

### Required method

1. Compile the unchanged Rust workspace first.
2. Create cross-language fixtures for all eight `vectors/outcome_semantics_vectors.json` cases.
3. Make Rust emit its observer receipt for each case.
4. Validate each receipt against `schemas/observer-receipt-v2.schema.json`.
5. Compare canonical bytes and semantic classification with Python.
6. Preserve every divergence before patching.
7. Patch the smallest component.
8. Run Rust format, Clippy, tests, Python tests, Node tests, Rocq compilation, source gate, provider contract gate, semantic divergence gate, and both red-team suites.

### Failure criteria

The work order fails if it:

* changes the schema to accept the weaker Rust receipt without justification;
* adds executor authority to the observer;
* treats missing provider evidence as failure;
* enables automatic logical retry;
* reports Rust parity without executing the vectors;
* reports Rocq proof acceptance without compiler output.

## Second work order

Compile `rocq/DurableState.v` and `rocq/CheckDurableState.v`, preserve `Print Assumptions` output, then compare the exact theorem preconditions with the executable Python guards. Look specifically for properties that are true only because the Rocq model abstracts away parsing, key ownership, provider read authority, or state persistence.

## Third work order

Design a credentialed Stripe test-mode experiment, but do not run it without explicit authorization and credentials. The experiment must include:

* a dedicated test account;
* a harmless object type;
* exact same-key connection interruption or proxy fault injection;
* independent read-back;
* webhook signature verification;
* event duplication and reordering handling;
* cleanup;
* a recorded boundary between transport replay and a new logical action.

## Output contract

Return:

1. exact command transcript;
2. compiler and dependency versions;
3. failing vectors before patch;
4. smallest patch;
5. complete rerun results;
6. updated claims matrix;
7. unresolved divergence list;
8. fresh extraction validation;
9. archive checksum.
