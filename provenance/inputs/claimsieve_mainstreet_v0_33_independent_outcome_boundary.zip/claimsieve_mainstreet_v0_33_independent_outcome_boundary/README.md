# MainStreet AI + ClaimSieve v0.33.0
## Independent Outcome Boundary

> Trust in an uncertain world.

This release is a research and engineering candidate for governing consequential agent actions. It is not described as production ready, secure in the general sense, or formally verified.

The release begins from a concrete v0.32 failure:

> A compromised executor produced a correctly signed but false rejection. No independent provider record existed. The observer accepted the executor narrative and finalized the action as `CONFIRMED_FAILURE`.

That trace violated the invariant that unknown outcomes remain unknown and the requirement that execution outcomes be established independently of the executor.

v0.33 removes the executor receipt from the observer's terminal-outcome trust path. The observer now classifies only independently readable provider evidence. Contradictory provider evidence remains `OUTCOME_UNKNOWN` and triggers containment.

## Release status

| Area | Status in this package |
|---|---|
| Python reference boundary | Implemented and executed |
| MainStreet proposal boundary | Implemented and executed |
| Concrete v0.32 violating trace | Reproduced and preserved |
| Patched trace | Executed and blocked |
| Stripe provider contract model | Implemented and executed offline |
| Live Stripe API integration | Not performed |
| Rust candidate | Implemented source, not compiled here |
| Rocq model | Formally modeled source, not compiled here |
| Distributed consensus backend | Designed only |
| Independent-host observer | Designed only |
| Live tax filing or payment | Disabled and absent |

## Core result

The trusted path was made smaller rather than larger:

```text
Executor attempt receipt ───────┐
                                ├─ audit and conflict evidence only
Independent provider read ──────┴─ terminal outcome authority
```

The observer no longer needs an executor verification key to determine success or failure. A signed executor statement cannot convert absent provider evidence into a terminal result.

## Unknown-outcome provider contract

The package models Stripe's published API v1 POST idempotency contract. The executable gate demonstrates:

* exact same-key and same-parameter replay after a connection drop does not create a duplicate inside the modeled retention window;
* request mutation is rejected;
* replay outside the conservative 24-hour window can duplicate if the ClaimSieve guard is bypassed;
* a cached 500 remains indeterminate;
* pre-execution validation failure is not cached in the model;
* revocation, changed reservation, key, request, endpoint, account, provider guarantee, or exhausted replay budget blocks transport replay.

This is a contract-derived offline test. It does not call Stripe or create an external object.

## Reproduced executable results

The final release harness records the exact outputs under `evidence/`. The expected current results are:

* 140 Python tests
* 18 Node tests
* 8 of 8 outcome semantics vectors
* 6 of 6 provider-contract scenarios
* 52 of 58 inherited red-team scenarios blocked or detected, 0 tested bypasses, 6 infrastructure limitations
* 25 of 29 durable-state scenarios blocked or detected, 0 tested bypasses, 4 infrastructure limitations

Native Rust and Rocq results remain unavailable in the originating environment and are not counted as passed.

## Fast review

Read [`START_HERE.md`](START_HERE.md), then run:

```bash
./scripts/test_all.sh
```

For the explicit native attempt:

```bash
./scripts/compile_native.sh
```

## Key artifacts

* [`docs/CONCRETE_INVARIANT_VIOLATION.md`](docs/CONCRETE_INVARIANT_VIOLATION.md)
* [`docs/SMALLEST_TCB_REMOVAL.md`](docs/SMALLEST_TCB_REMOVAL.md)
* [`docs/STRIPE_PROVIDER_CONTRACT_TEST.md`](docs/STRIPE_PROVIDER_CONTRACT_TEST.md)
* [`docs/SEMANTIC_DIVERGENCE_REPORT.md`](docs/SEMANTIC_DIVERGENCE_REPORT.md)
* [`docs/NATIVE_COMPILATION_REPORT.md`](docs/NATIVE_COMPILATION_REPORT.md)
* [`docs/CLAIMS_AND_EVIDENCE_MATRIX.md`](docs/CLAIMS_AND_EVIDENCE_MATRIX.md)
* [`docs/TEST_REPORT.md`](docs/TEST_REPORT.md)
* [`docs/REMAINING_LIMITATIONS.md`](docs/REMAINING_LIMITATIONS.md)
* [`CODEX_HANDOFF.md`](CODEX_HANDOFF.md)

## Repository map

```text
mainstreet/        Pure customer-facing proposal boundary
python/            Executed reference implementation and tests
rust/              Production-language candidate, source only here
rocq/              Narrow formal model, not compiler-accepted here
schemas/           Strict protocol schemas
security/          Threat model, invariants, and abuse cases
research/          Provider-contract snapshot and source mapping
vectors/           Portable and outcome-semantic fixtures
scripts/           Gates, attacks, packaging, and native attempts
evidence/          Raw outputs and preserved traces
docs/              Architecture, reports, decisions, and limitations
```

## Nonclaims

This release does not establish that:

* a remote provider always follows its published contract;
* Stripe webhooks are independent or sufficient outcome evidence;
* the Rust code compiles or matches Python;
* the Rocq scripts compile or prove implementation behavior;
* SQLite provides distributed linearizability;
* one host provides independent failure domains;
* a signed claim is true;
* a hash-chained ledger is semantically correct;
* a live tax, payment, messaging, deployment, or production action is safe to enable.
