# Native Compilation Report

## Requested gates

Rust:

```bash
cargo fmt --check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-features
```

Rocq:

```bash
rocq compile -Q . ClaimSieve Claimsieve.v
rocq compile -Q . ClaimSieve DurableState.v
rocq compile -Q . ClaimSieve Check.v
rocq compile -Q . ClaimSieve CheckDurableState.v
```

Equivalent `coqc` commands are supported when the legacy executable is present.

## Actual environment

The originating environment did not contain:

* `cargo`
* `rustc`
* `rustup`
* `rocq`
* `coqc`
* `opam`
* `ocaml`
* Docker or Podman

Outbound package and toolchain retrieval was unavailable. The connected GitHub application returned no accessible repository, so a remote workflow could not be started from this session.

The explicit attempt is recorded in `evidence/NATIVE_COMPILATION_ATTEMPT.txt` and exits with code `2` when toolchains are unavailable.

## Status

| Gate | Status |
|---|---|
| Rust parse/type check | Blocked by environment |
| Rust format | Blocked by environment |
| Rust Clippy | Blocked by environment |
| Rust unit tests | Blocked by environment |
| Rocq compilation | Blocked by environment |
| Rocq `Print Assumptions` audit | Blocked by environment |
| Static Rust boundary scan | Executed, not compilation |
| Static Rocq escape scan | Executed, not proof acceptance |

## Included external execution paths

* `.github/workflows/rust.yml`
* `.github/workflows/rocq.yml`
* `scripts/compile_native.sh`
* `scripts/test_rocq_docker.sh`

These files make the next execution step reproducible, but workflow presence is not evidence that a workflow ran.
