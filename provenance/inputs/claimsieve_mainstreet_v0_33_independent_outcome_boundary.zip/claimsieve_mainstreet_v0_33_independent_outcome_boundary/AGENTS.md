# Binding Instructions for Coding Agents

These rules apply to every coding agent, reviewer, and automated patch operating in this repository.

## Evidence first

1. Reproduce existing gates before editing.
2. Name the exact invariant under test.
3. Create a discriminating test that would fail if the invariant were false.
4. Preserve the original trace and the patched trace.
5. Do not replace a failing test with a weaker expectation.

## Claim discipline

Use only these statuses:

* Implemented and executed
* Implemented but not executed
* Designed but not implemented
* Assumed
* Formally modeled
* Formally proved
* Outside the proof boundary
* Blocked by environment limitations

Source inspection is not compilation. A proof file without compiler acceptance is not a proved theorem. A deterministic simulator is not a live provider integration. A signature proves origin and integrity, not truth.

## Authority boundaries

MainStreet, OpenClaw, models, tools, and subagents must not gain direct side-effect authority. A proposal is not a permit. A permit is not execution. An executor receipt is not independent outcome evidence.

Do not add any path that permits the executor to sign observer receipts, select its own trust root, authorize a new logical attempt, or collapse unknown outcome into failure.

## Provider testing

Do not call a live provider or create external effects without explicit user authorization and valid credentials. Contract-derived tests must state that they are offline models. Live tests must use a dedicated test account, bounded objects, exact cleanup procedures, and separately recorded consent.

## Native toolchains

When Rust is available, run:

```bash
cd rust
cargo fmt --check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-features
```

When Rocq is available, run the commands in `scripts/compile_native.sh` and preserve the complete output. Do not edit proof statements solely to make compilation pass without documenting the semantic change.

## Divergence over consensus

Do not report that Python, Rust, Rocq, schemas, and prose "agree" unless each comparison is precise. Search first for:

* differing field sets;
* differing default behavior;
* differing unknown-state handling;
* differing retry semantics;
* differing sequence or time bounds;
* differing canonicalization;
* differing proof preconditions;
* differing trust-root ownership.

Every resolved divergence must retain a regression test. Every unresolved divergence must remain visible in `docs/SEMANTIC_DIVERGENCE_REPORT.md` and the machine-readable evidence report.
