# Remaining Limitations — v0.33.0

## 1. Native toolchains were unavailable

Rust and Rocq were not compiled. Source changes may contain syntax, type, dependency, or semantic defects.

## 2. Rust observer receipt divergence

Rust emits an observer receipt v1 shape while Python and the schema use v2. Portable verifier and canonicalization parity are not established.

## 3. Provider test is contract-derived, not live

The Stripe model is grounded in official documentation but did not use a credential, network fault injection, webhook, or external object.

## 4. Provider contract adherence is an assumption

A provider defect, incident, undocumented behavior, account-specific behavior, or contract change can invalidate the model.

## 5. Provider evidence can still be wrong

An independently queried record may be stale, incomplete, misbound to an account, or semantically misleading. Independent does not mean infallible.

## 6. Observer independence is logical, not infrastructural

The simulation uses distinct keys and a read-only interface but still runs on the same host and administrative environment.

## 7. SQLite is not distributed consensus

The local durable boundary does not establish behavior under multi-node partitions, stale leaders, cross-region failover, or administrator compromise.

## 8. Remote side effects cannot share one atomic transaction with local state

Dispatch and remote effect remain separated by a failure boundary. Reconciliation is required after the commit point.

## 9. Human approval remains fallible

The system can bind an approval but cannot prove comprehension, voluntariness, competence, or legal sufficiency.

## 10. Signatures do not prove truth

Signed policy, evidence, executor, provider, observer, or witness records can still contain false semantic claims.

## 11. Supply-chain provenance is incomplete

No resolved Rust lockfile, signed build provenance, transparency-log entry, or independently reproduced binary is included.

## 12. MainStreet product maturity remains limited

The proposal boundary exists, but the complete owner-facing tax-notice workspace, privacy controls, professional escalation, and real customer usability evidence remain unfinished.
